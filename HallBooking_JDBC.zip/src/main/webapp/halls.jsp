<%@ page import="java.util.List" %>
<%@ page import="com.hallbooking.model.Hall" %>
<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Halls</title>
<link rel="stylesheet" href="css/style.css"></head><body>
<div class="container"><h1>Available Halls</h1>
<% List<Hall> halls=(List<Hall>)request.getAttribute("halls");
for(Hall h:halls){ %>
<div class="card">
<h2><%=h.getHallName()%></h2>
<p>Location: <%=h.getLocation()%></p>
<p>Capacity: <%=h.getCapacity()%> people</p>
<p>Price: ₹<%=h.getPrice()%></p>
<p>Status: <%=h.getStatus()%></p>
<a class="btn" href="booking.html?hallId=<%=h.getId()%>">Book Now</a>
</div>
<% } %>
</div></body></html>
