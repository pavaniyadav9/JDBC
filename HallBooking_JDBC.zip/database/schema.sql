CREATE DATABASE IF NOT EXISTS hallbooking;
USE hallbooking;

CREATE TABLE users (
 id INT PRIMARY KEY AUTO_INCREMENT,
 name VARCHAR(100) NOT NULL,
 email VARCHAR(150) UNIQUE NOT NULL,
 password VARCHAR(255) NOT NULL,
 phone VARCHAR(20)
);

CREATE TABLE halls (
 id INT PRIMARY KEY AUTO_INCREMENT,
 hall_name VARCHAR(100) NOT NULL,
 location VARCHAR(150) NOT NULL,
 capacity INT NOT NULL,
 price DECIMAL(10,2) NOT NULL,
 status VARCHAR(20) DEFAULT 'AVAILABLE'
);

CREATE TABLE bookings (
 id INT PRIMARY KEY AUTO_INCREMENT,
 user_id INT NOT NULL,
 hall_id INT NOT NULL,
 booking_date DATE NOT NULL,
 status VARCHAR(20) DEFAULT 'BOOKED',
 FOREIGN KEY (user_id) REFERENCES users(id),
 FOREIGN KEY (hall_id) REFERENCES halls(id),
 UNIQUE KEY unique_hall_date (hall_id, booking_date)
);

INSERT INTO halls(hall_name,location,capacity,price) VALUES
('Sri Convention Hall','Hyderabad',500,25000),
('Green Palace Hall','Hyderabad',300,18000),
('Royal Function Hall','Secunderabad',700,35000);
